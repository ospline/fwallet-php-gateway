<?php
/**
 * Plugin Name: Fwallet Getaway 019
 * Plugin URI:  https://fwallet.com
 * Description: Fwallet Payment Gateway for WooCommerce.
 * Version:     1.0.0
 * Author:      Fwallet company LTD
 * Author URI:  https://fwallet.com
 * License:     GPL-2.0+
 * Text Domain: fwallet-getaway
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

add_action( 'plugins_loaded', 'init_fwallet_payment_gateway_class' );

function init_fwallet_payment_gateway_class() {

    if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
        return;
    }

    class WC_Gateway_Fwallet extends WC_Payment_Gateway {

        public function __construct() {
            $this->id                 = 'fwallet'; // Unique ID for your gateway
            $this->icon               = ''; // URL of the icon that will be displayed on checkout page near your gateway name
            $this->has_fields         = false; // Set to true if you need custom fields on checkout
            $this->method_title       = 'Fwallet Getaway 019'; // Title shown in admin
            $this->method_description = 'Accept payments via Fwallet secure payment gateway.'; // Description shown in admin

            $this->init_form_fields();
            $this->init_settings();

            $this->title        = $this->get_option( 'title' );
            $this->description  = $this->get_option( 'description' );
            $this->enabled      = $this->get_option( 'enabled' );
            $this->api_key      = $this->get_option( 'api_key' );
            $this->api_endpoint = $this->get_option( 'api_endpoint' );

            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            
            add_action( 'woocommerce_api_wc_gateway_fwallet_return', array( $this, 'check_fwallet_response' ) );
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => 'Enable/Disable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable Fwallet Payment',
                    'default' => 'yes'
                ),
                'title' => array(
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'This controls the title which the user sees during checkout.',
                    'default'     => 'Fwallet',
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                    'default'     => 'Pay securely using your Fwallet account.',
                ),
                'api_endpoint' => array(
                    'title'       => 'API Base URL Link',
                    'type'        => 'text',
                    'description' => 'Enter the base API endpoint URL (e.g., https://yourdomain.com/api/create_payment.php)',
                    'default'     => '',
                    'desc_tip'    => true,
                ),
                'api_key' => array(
                    'title'       => 'API Key',
                    'type'        => 'password',
                    'description' => 'Enter your Fwallet API Key from the Merchant Dashboard.',
                    'default'     => '',
                    'desc_tip'    => true,
                )
            );
        }

        public function process_payment( $order_id ) {
            global $woocommerce;
            $order = wc_get_order( $order_id );

            
            // Generate return URLs
            $success_url = add_query_arg(
                array(
                    'wc-api'   => 'wc_gateway_fwallet_return',
                    'order_id' => $order_id,
                    'status'   => 'success'
                ),
                home_url( '/' )
            );

            $cancel_url = $order->get_cancel_order_url();

            $product_names = array();
            foreach ( $order->get_items() as $item_id => $item ) {
                $product_names[] = $item->get_name();
            }
            $product_name_string = implode( ', ', $product_names );
            
            // Limit product name string length if needed by API, though not specified in docs.
            if(strlen($product_name_string) > 100){
                 $product_name_string = substr($product_name_string, 0, 97) . '...';
            }

            $payment_data = array(
                'api_key'      => $this->api_key,
                'amount'       => (float) $order->get_total(),
                'product_name' => $product_name_string,
                'success_url'  => $success_url,
                'cancel_url'   => $cancel_url
            );

            $api_url = $this->api_endpoint;
            
            if ( empty( $api_url ) || empty( $this->api_key ) ) {
                wc_add_notice( 'Payment error: API Endpoint or API Key is missing. Please contact the store administrator.', 'error' );
                return;
            }

            $response = wp_remote_post( $api_url, array(
                'method'      => 'POST',
                'timeout'     => 45,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking'    => true,
                'sslverify'   => false, // SSL ইস্যু এড়াতে যোগ করা হলো
                'headers'     => array(
                    'Content-Type' => 'application/json'
                ),
                'body'        => json_encode( $payment_data ),
                'cookies'     => array()
            ) );

            if ( is_wp_error( $response ) ) {
                $error_message = $response->get_error_message();
                wc_add_notice( 'Payment Error: Could not connect to Fwallet API. ' . $error_message, 'error' );
                return;
            }

            $response_body = wp_remote_retrieve_body( $response );
            $result = json_decode( $response_body, true );

            if ( isset( $result['status'] ) && $result['status'] === 'success' && ! empty( $result['checkout_url'] ) ) {
                
                // Mark order as pending payment
                $order->update_status( 'pending', 'Awaiting Fwallet payment.' );
                
                // Empty cart
                $woocommerce->cart->empty_cart();
                
                // Return redirect to Fwallet checkout URL
                return array(
                    'result'   => 'success',
                    'redirect' => $result['checkout_url']
                );
            } else {
                // উন্নত এরর হ্যান্ডলিং - আসল সমস্যাটি কী তা দেখার জন্য
                if ( isset( $result['message'] ) ) {
                    $error_msg = $result['message']; // API থেকে আসা সরাসরি মেসেজ
                } elseif ( json_last_error() !== JSON_ERROR_NONE ) {
                    // API থেকে JSON এর বদলে অন্য কিছু (যেমন 404 HTML পেজ বা Cloudflare ক্যাপচা) আসলে
                    $error_msg = 'Invalid API Response! (Check URL). Raw: ' . esc_html( wp_trim_words( $response_body, 12, '...' ) );
                } else {
                    // JSON ঠিক আছে কিন্তু success স্ট্যাটাস নেই
                    $error_msg = 'API Error: ' . esc_html( wp_trim_words( $response_body, 12, '...' ) );
                }
                
                wc_add_notice( 'Payment Failed: ' . $error_msg, 'error' );
                return;
            }
        }
        
        public function check_fwallet_response() {
            // Check if the required parameters are present in the URL
            if ( isset( $_GET['order_id'] ) && isset( $_GET['status'] ) && $_GET['status'] === 'success' ) {
                $order_id = intval( $_GET['order_id'] );
                $order    = wc_get_order( $order_id );

                if ( $order ) {
                    // However, based on the provided documentation, success_url is the only confirmation.
                    // Assuming Fwallet verified the TRX ID before redirecting here.
                    
                    if ( $order->get_status() !== 'processing' && $order->get_status() !== 'completed' ) {
                        // Mark the order as paid/processing
                        $order->payment_complete();
                        $order->add_order_note( 'Payment completed successfully via Fwallet.' );
                    }
                    
                    // Redirect to WooCommerce Thank You page
                    wp_redirect( $this->get_return_url( $order ) );
                    exit;
                }
            }
            
            // Fallback redirect to home if something goes wrong
            wp_redirect( home_url( '/' ) );
            exit;
        }
    }
}

add_filter( 'woocommerce_payment_gateways', 'add_fwallet_gateway_class' );
function add_fwallet_gateway_class( $gateways ) {
    $gateways[] = 'WC_Gateway_Fwallet'; // Add our custom gateway class
    return $gateways;
}